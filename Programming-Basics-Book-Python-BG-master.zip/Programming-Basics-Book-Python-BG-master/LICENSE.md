This book is licensed under the [CC-BY-SA](https://creativecommons.org/licenses/by-sa/4.0/) open-source license.
